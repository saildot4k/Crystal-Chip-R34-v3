Just replace the default english lang.lng in the mca launch dir with the translated one.
Or delete the lang.lng file to display the text in Polish.